import{X as a}from"./CuqPCOm1.js";a();
