import{a as t}from"../chunks/B9IOJEXW.js";export{t as start};
